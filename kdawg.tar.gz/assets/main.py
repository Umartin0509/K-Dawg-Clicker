import pygame
import sys
import os
import platform
import subprocess
from pathlib import Path

# Safe import for winsound (Windows only)
if platform.system() == "Windows":
    import winsound as ws

def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

# Resolve file paths using resource_path
files_to_open = [
    resource_path("KDawg_pic.png"),
    resource_path("KDawg_pic.jpg"),
    resource_path("KDawg_pic.tif"),
    resource_path("KDawg_pic.jxr"),
    resource_path("KDawg_pic.heic"),
    resource_path("KDawg_pic.bmp")
]

# Initialize Pygame
pygame.init()

WINDOW_WIDTH = 1300
WINDOW_HEIGHT = 900
screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("Custom Image with Hitbox")
clock = pygame.time.Clock()

def open_file_in_default_app(file_path):
    path = Path(file_path).resolve()
    
    if not path.exists():
        print(f"File not found: {path}")
        return

    system_name = platform.system()

    try:
        if system_name == "Windows":
            os.startfile(path)
        elif system_name == "Darwin":  # macOS
            subprocess.run(["open", str(path)], check=True)
        elif system_name == "Linux":
            subprocess.run(["xdg-open", str(path)], check=True)
    except Exception as e:
        print(f"Failed to open file: {e}")

# Fonts and static text
font1 = pygame.font.SysFont('freesansbold', 80)
font2 = pygame.font.SysFont('freesansbold', 40)

text1 = font1.render("Click the K Dawg", True, (255, 255, 0))
textrect1 = text1.get_rect(center=(WINDOW_WIDTH // 2, WINDOW_HEIGHT // 8))

text2 = font2.render("K Dawgs Clicked = 0", True, (255, 255, 0))
textrect2 = text2.get_rect(center=(WINDOW_WIDTH // 2, WINDOW_HEIGHT - WINDOW_HEIGHT // 8))

class CustomImageSprite(pygame.sprite.Sprite):
    def __init__(self, image_path, x, y, width, height):
        super().__init__()
        
        try:
            self.image = pygame.image.load(resource_path(image_path)).convert_alpha()
        except pygame.error:
            print(f"Could not load '{image_path}'. Creating default placeholder.")
            self.image = pygame.Surface((120, 80), pygame.SRCALPHA)
            self.image.fill((100, 200, 100))

        self.image = pygame.transform.scale(self.image, (width, height))
        self.rect = self.image.get_rect(topleft=(x, y))
        self.mask = pygame.mask.from_surface(self.image)

# Create instances of sprites
sprite = CustomImageSprite('KDawg_pic.png', 450, 250, 400, 400)
sprite2 = CustomImageSprite('crash_screen.png', 0, 0, 1300, 900)

all_sprites = pygame.sprite.Group(sprite)
sprite2s = pygame.sprite.Group(sprite2)

DEAD = False
running = True

# Load and play background music
try:
    pygame.mixer.music.load(resource_path('05. Loonboon.mp3'))
    pygame.mixer.music.set_volume(0.5)
    pygame.mixer.music.play(loops=-1)
except pygame.error as e:
    print(f"Could not load music file: {e}")

w = 9

# Main Game Loop
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                if sprite.rect.collidepoint(event.pos):
                    pygame.mixer.music.pause()
                    DEAD = True
                    running = False

    screen.fill((0, 255, 0))
    all_sprites.draw(screen)
    screen.blit(text1, textrect1)
    screen.blit(text2, textrect2)

    pygame.display.flip()
    clock.tick(60)

# Dead State Loop
while DEAD:
    sprite2s.draw(screen)
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
    
    pygame.display.flip()

    # Trigger sound and open files ONLY ONCE when w == 9
    if w == 9:
        if platform.system() == "Windows":
            ws.PlaySound("SystemExit", ws.SND_ALIAS)
        
        for file_name in files_to_open:
            open_file_in_default_app(file_name)
            
        w = 0  # Prevents this block from re-running every frame

    clock.tick(60)

pygame.quit()
sys.exit()